var searchData=
[
  ['id_154',['id',['../classProducto.html#ac7e63125ce8671260d15e473e689efa4',1,'Producto']]],
  ['id_5fciudad_155',['id_ciudad',['../classCiudad.html#ab7e0d1416356c18ddbfbda3ec6df8552',1,'Ciudad']]]
];
