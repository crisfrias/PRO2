var searchData=
[
  ['redistribuir_147',['redistribuir',['../classRio.html#a20b87de3f14bbd25194882b7f123233e',1,'Rio']]],
  ['redistribuir_5fpriv_148',['redistribuir_priv',['../classRio.html#af5e24407c6b3f93b1a35006586bd1b09',1,'Rio']]],
  ['reiniciar_5fbarco_149',['reiniciar_barco',['../classBarco.html#abe7d10045cd11e8e7983041dac9a10be',1,'Barco']]],
  ['rio_150',['Rio',['../classRio.html#a1dc8b1e6f2e4d7087575bf051abb28f4',1,'Rio']]]
];
