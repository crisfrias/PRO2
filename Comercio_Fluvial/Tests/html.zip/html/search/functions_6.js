var searchData=
[
  ['inventario_134',['Inventario',['../classInventario.html#ab7ca21da6822bc59fa236f7238e20fd3',1,'Inventario::Inventario()'],['../classInventario.html#abadfdbda752f37aa672b8db9e5a773a0',1,'Inventario::Inventario(int n)']]]
];
