var searchData=
[
  ['historial_153',['historial',['../classBarco.html#a857227a09bc9a4ffa4cb229456209107',1,'Barco']]]
];
