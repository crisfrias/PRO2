var searchData=
[
  ['devolver_5fproducto_36',['devolver_producto',['../classInventario.html#adff99f95b49b6913b04faae4298f211d',1,'Inventario']]]
];
