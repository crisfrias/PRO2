var searchData=
[
  ['tamano_5finv_5fciudad_77',['tamano_inv_ciudad',['../classCiudad.html#a4126b2b69a2596ef1583f36102fee953',1,'Ciudad']]],
  ['tamano_5finventario_78',['tamano_inventario',['../classInventario.html#acbb01ef7cc58d0fe281ce1195adf491b',1,'Inventario']]]
];
