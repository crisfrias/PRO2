var searchData=
[
  ['hacer_5fviaje_39',['hacer_viaje',['../classRio.html#a67a10c7e89ea00c401cd1285a2830d55',1,'Rio']]],
  ['hacer_5fviaje_5fpriv_40',['hacer_viaje_priv',['../classRio.html#a8cf1dbced931c4284a78d5963b8cbdfe',1,'Rio']]],
  ['historial_41',['historial',['../classBarco.html#a857227a09bc9a4ffa4cb229456209107',1,'Barco']]]
];
