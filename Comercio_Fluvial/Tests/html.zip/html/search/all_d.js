var searchData=
[
  ['ultimo_5fid_79',['ultimo_id',['../classInventario.html#aa215d7c5bcb50549a5a534db9a75b82c',1,'Inventario']]]
];
